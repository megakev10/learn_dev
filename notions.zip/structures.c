/* Parlons des structures. 
Les structures, c'est comme les classes en POO. Elles servent a regrouper des informations. Mais a la differrence de celles ci, il n y a pas de methodes*/
#include <stdio.h>
#include <stdlib.h>
struct carte_rfid {// Donc la on cree une structure
  char uid[8];// et on met ses elements
  int id;
  int niveau_d_access;
};
int main(){
  struct carte_rfid carte_bleue;// Ici on declare un objet avec la structure
  struct carte_rfid carte_blanche;
  scanf("%s",carte_bleue.uid);// On recupere son "uid".
  scanf("%d", &carte_bleue.id);
  scanf("%d", &carte_bleue.niveau_d_access);
  puts(carte_bleue.uid);
  printf("%d\n",carte_bleue.id);
  printf("%d\n",carte_bleue.niveau_d_access);// On doit afficher chaque elt a son tour."C" ne sait pas faire ca.
  carte_blanche = carte_bleue;//"carte_blanche" recoit tout de "carte_bleue"
    puts(carte_blanche.uid);
    printf("%d\n",carte_blanche.id);
    printf("%d\n",carte_blanche.niveau_d_access);
}
