/* Apprentissage de l'allocation dynamique de la memoire. 
La RAM possede une partie "stack" et une partie "heap".
*/
#include <stdio.h>
#include <stdlib.h>// on doit toujours declarer cette lib quand on veut faire de l'allocation dynamique.
int main()
{
int a = 2;// ceci est une allocation dynamique de la memoire dans la partie "stack" de la memoire RAM
int *p;// le pointeur "p" est aussi cree dans la "stack"
p = malloc(4);// Ici, le pointeur p va pointer vers une addresse cette fois ci dans la partie "heap" de la memoire. Et cette case reservee en "heap" est de taille 4 bits (pour stocker un entier). On pouvait aussi faire p = malloc(sizeof(int)).
printf("%p\n",p);
printf("%d\n",*p);// On obtiendra une "garbage value" (resultat d'un precedent prog) ou rien du tout : malloc cree juste mais n'initialise pas.
free (p);// la on efface la case vers laquelle pointais "p"."p" peut donc etre alloues vers d'autres addresses.
float *T = malloc(5*sizeof(float));// ici on cree un tableau de reels a 05 cases.
float *Tab = calloc (5,sizeof(float));// ceci est l'equivalent d'un "malloc" + initialisation.
for (int i=0; i<5; i++){
  printf("%.2f\n", *(T + i));
  printf("%.2f\n", *(Tab + i));
}
T= realloc(T, 8*sizeof(float));// On ajoute des 03 cases a notre tableau
Tab= realloc(Tab, 8*sizeof(float));// meme chose ici. Donc que ce soit declare avec "malloc" ou "calloc", c'est la misma cosa
for (int i=0; i<8; i++){
  printf("%.2f\n", *(T + i));
  printf("%.2f\n", *(Tab + i));
}
}



