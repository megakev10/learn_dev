#include <iostream>// ca c'est une sorte de "stdio.h"
int main(){
  std:: cout << "Bienvenue dans le monde du C++\n";//"std::" est juste un namespace de standard. En fait il permet de dire au compilateur, utilise le "cout" de la biblio "standard". Comme ca meme si plusieurs biblios ont un "cout", le compilateur sait lequel utiliser.
}
