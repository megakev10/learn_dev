/* On va travailler sur la recursivite.
Deja, la recursivite c'est le fait pour une fonction de s'appeller elle meme*/
#include <stdio.h>
#include <stdlib.h>
int somme (int s){ 
  if(s == 0){ // ceci c'est la condition de base. Elle permet surtout l'arret de la fonction
    return 0;
  }else{ 
    return s + somme(s-1);// le cas general, c'est ici que la fonction s'appelle recursivement.
  }
}
int main()
{
int n;
printf("Vous voulez calculer la somme jusqu'a 0 de quel nombre? ");
scanf("%d",&n);
somme(n);
printf("Votre somme est %d", somme(n));
}
