#include<stdio.h>
#include<string.h>// cette biblio permet d'utiliser des fonctions speciales sur des chaines de caracteres (tableaux de caracteres)
int main(){
char commande[10], message[10];
char Ecriture[]="read";
char Lecture[]="write";
char sortir[]="exit";
int result1,result2,i;
float donnees[3];
do{
printf("initialisation du protocole SPI...\n");
printf("connexion etablie, pret a communiquer\n");
do {
printf("Que voulez vous faire?\n");
scanf("%s",commande);//  pour recuperer les valeurs a mettre dans le tableau sauf que les espaces ne sont pas pris en comptent.
//gets("%s",commande);//  pour recuperer les valeurs a mettre dans le tableau. A la difference de "scanf", meme les espaces sont pris en comptent.
printf("commande %s\n", commande);// Avec "%s" on affiche immediatement toute la chaine sans le "\0".
result1 = strcmp(commande,Ecriture);// ici c'est une compairaison qui se fait surtout sous forme de soustraction (on soustrait les numeros ASCII des caracteres de la 1ere chaine et de la 2eme de meme indice. Le resultat peut donc etre negatif. En cas d'egalite, on a "0".
result2 = strcmp(commande,Lecture);
//printf("%d\n%d",result1,result2);
} while(!(result1 != 0 ^ result2 != 0));
if (result1 == 0){
printf("les donnees en memoire sont:\n");
  for(i=0;i<3;i++){
    printf("  %.2f",donnees[i]);// ce ".2" permet d'afficher 2 chiffres apres virgule
  }}
printf(" \n");
if (result2 == 0){
printf("recuperation des donnees des capteurs ");
  for(i=0;i<3;i++){
    scanf("%f",&donnees[i]);
  }
}
printf("pour quitter, tapez \'exit\', sinon tapez n'importe quoi pour continuer ");
scanf("%s",message);
}while(strcmp(message, sortir) != 0);
}
