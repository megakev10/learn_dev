import cadquery as cq
from pathlib import Path

# === PARAMÈTRES ===
step_file = Path(__file__).parent / "slave1.STEP"

tolerance = 0.3
wall_thickness = 2.0
bottom_thickness = 1.5
lid_thickness = 2.0
internal_clearance_z = 3.0

screw_diameter = 2.2
screw_post_diameter = 5.0

# === SUPPORT ROTATIF (AXE) ===
pivot_diameter = 8      # diamètre axe
pivot_length = 10       # longueur qui sort
pivot_offset_z = 0      # centré verticalement

# === IMPORT STEP ===
pcb = cq.importers.importStep(str(step_file))

bbox = pcb.val().BoundingBox()

pcb_length = bbox.xlen
pcb_width = bbox.ylen
pcb_height = bbox.zlen

# === DIMENSIONS ===
inner_length = pcb_length + 2 * tolerance
inner_width = pcb_width + 3 * tolerance
inner_height = pcb_height + internal_clearance_z

outer_length = inner_length + 2 * wall_thickness
outer_width = inner_width + 2 * wall_thickness
outer_height = inner_height + bottom_thickness+ 2.7

# === BASE ===
base = cq.Workplane("XY").box(outer_length, outer_width, outer_height)
# Creuser intérieur
base = (
    base
    .faces(">Z")
    .workplane()
    .rect(inner_length, inner_width)
    .cutBlind(-inner_height)
)
base = base.edges("|Z").fillet(2.0)
# === TROUS VIS ===
offset_x = inner_length / 2 - 4
offset_y = inner_width / 2 - 2.5
points = [(x, y) for x in [-offset_x, offset_x] for y in [-offset_y, offset_y]]
base = (
    base
    .faces(">Z")
    .workplane()
    .pushPoints(points)
    .hole(screw_diameter)
)
# === COUVERCLE ===
lid = cq.Workplane("XY").box(outer_length, outer_width, lid_thickness)
lid = lid.translate((0, 0, outer_height + lid_thickness/2))
lid = lid.edges("|Z").fillet(2.0)
lid = (
    lid
    .faces("<Z")  # dessous du couvercle
    .workplane()
    .pushPoints(points)
    .circle(screw_post_diameter / 2)
    .extrude(inner_height)
)
lid = (
    lid
    .faces("<Z")
    .workplane()
    .pushPoints(points)
    .hole(screw_diameter, depth=inner_height)
)
# reset contexte
base = cq.Workplane("XY").newObject([base.val()])

# === OUVERTURES ===

# USB-C (à ajuster)
usb_width = 10
usb_height = 5
usb_y = -2        
usb_z = 2.75   

base = (
    base
    .faces(">X")
    .workplane()
    .center(usb_y, usb_z)
    .slot2D(usb_width, usb_height)
    .cutBlind(-wall_thickness)
)
base = base.edges(">X").chamfer(0.5)

# LED IR 
led_diameter = 5 
led_x=12.35 
led_y=-11 
lid = ( lid .faces(">Z") .workplane() .center(led_x, led_y) .hole(led_diameter) )

# reset contexte
base = cq.Workplane("YZ").newObject([base.val()])
# === AXE DE FIXATION ROTATIF ===

base = (
    base 
    .faces("<X")  # arrière du boîtier 
    .workplane()
    .center(0, pivot_offset_z)
    .circle(pivot_diameter / 2)
    .extrude(pivot_length)  # sort vers l'arrière
)
base = cq.Workplane("YZ").newObject([base.val()])
# === GORGE DE CLIP (VERSION AVEC FACES) ===

# 1. voir la face
show_object(base.faces("<X"), name="face_X")

# 2. workplane
wp = base.faces("<X").workplane(offset=-pivot_length/2)
show_object(wp, name="wp")

# 3. cercle
test = wp.circle((pivot_diameter ) / 2)
show_object(test, name="circle")

# 4. cut (une fois validé)
base = wp.cutBlind(-2)

wp2= base.faces("<X").workplane(offset=-pivot_length/2)
test2 = wp2.circle((pivot_diameter - 1.2) / 2)
show_object(test2, name="circle2")
base =wp2.extrude(-2)

# === EXPORT ===
cq.exporters.export(base, "base.stl")
cq.exporters.export(lid, "lid.stl")

# DEBUG
show_object(base, name="Base", options={"color": (0, 0, 0)})
show_object(lid, name="Lid", options={"color": (0, 0, 0)})
show_object(pcb, name="PCB")

